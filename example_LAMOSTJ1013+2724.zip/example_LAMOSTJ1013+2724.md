# https://iopscience.iop.org/article/10.3847/1538-4357/adc0fa


```python
from astroAriadne_binary.star import Star
ra = 153.4847
dec = 27.40305
starname = '651211'
gaia_id = 739390405396929152

s = Star(starname, ra, dec, gaia_id)
```

    [37m
    		#####################################[0m
    [37m		##             ARIADNE             ##[0m
    [37m		#####################################[0m
    [37m   spectrAl eneRgy dIstribution[0m [37mbAyesian moDel averagiNg fittEr[0m
    [37m			Star : [0m[37m651211[0m
    [37m		*** LOOKING UP ARCHIVAL INFORMATION ***[0m
    INFO: Query finished. [astroquery.utils.tap.core]
    Warning!: CatalogWarning
    Warning message: Parameter radius not found! Be advised.
    Warning!: CatalogWarning
    Warning message: Parameter lum not found! Be advised.
    INFO: Query finished. [astroquery.utils.tap.core]
    Star not found in catalog TYCHO2.
    INFO: Query finished. [astroquery.utils.tap.core]
    Star not found in catalog Pan-STARRS.
    INFO: Query finished. [astroquery.utils.tap.core]
    Star not found in catalog SDSS.
    INFO: Query finished. [astroquery.utils.tap.core]
    INFO: Query finished. [astroquery.utils.tap.core]
    INFO: Query finished. [astroquery.utils.tap.core]
    Star not found in catalog APASS.
    Looking online for archival magnitudes for star 651211
    Checking catalog All-WISE
    Checking catalog Gaia DR3
    Checking catalog 2MASS
    Checking catalog GLIMPSE
    Warning!: CatalogWarning
    Warning message: Star is not available in catalog GLIMPSE. Skipping
    Checking catalog GALEX
    Checking catalog TICv8
    Warning!: CatalogWarning
    Warning message: Star is not available in catalog SkyMapper. Skipping
    Warning!: CatalogWarning
    Warning message: Star is not available in catalog STROMGREN_PAUNZ. Skipping
    Warning!: CatalogWarning
    Warning message: Star is not available in catalog STROMGREN_HAUCK. Skipping
    Warning!: CatalogWarning
    Warning message: Star is not available in catalog MERMILLIOD. Skipping
    [31m			Gaia DR3 ID : 739390405396929152[0m
    [31m			TIC : 241194894[0m
    [31m			Gaia Effective temperature : [0m[31m4016.500 +/- 323.783[0m
    [31m			Gaia Stellar radius : [0m[31m0.000 +/- 0.000[0m
    [31m			Gaia Stellar Luminosity : [0m[31m0.000 +/- 0.000[0m
    [31m			Gaia Parallax : [0m[31m7.522 +/- 0.064[0m
    [31m			Bailer-Jones distance : [0m[31m132.924 +/- 1.098[0m
    [31m			Maximum Av : [0m[31m0.106[0m
    
    [34m		       Filter       	Magnitude	Uncertainty[0m
    [34m		--------------------	---------	-----------[0m
    [34m		     GALEX_FUV      	 18.0330 	  0.0710   [0m
    [34m		     GALEX_NUV      	 17.9560 	  0.0470   [0m
    [34m		    GaiaDR2v2_BP    	 17.5335 	  0.0167   [0m
    [34m		    GaiaDR2v2_G     	 16.6263 	  0.0044   [0m
    [34m		    GaiaDR2v2_RP    	 15.5819 	  0.0187   [0m
    [34m		        TESS        	 15.5996 	  0.0259   [0m
    [34m		      2MASS_J       	 13.8250 	  0.0250   [0m
    [34m		      2MASS_H       	 13.2550 	  0.0290   [0m
    [34m		      2MASS_Ks      	 12.9470 	  0.0280   [0m
    [34m		    WISE_RSR_W1     	 12.8400 	  0.0240   [0m
    [34m		    WISE_RSR_W2     	 12.6470 	  0.0250   [0m
    



```python
s.remove_mag('WISE_RSR_W1')
s.remove_mag('WISE_RSR_W2')
s.remove_mag('GaiaDR2v2_BP')
s.remove_mag('GaiaDR2v2_RP')
s.remove_mag('GaiaDR2v2_G')
s.remove_mag('TESS')
```

    [33m			Removed WISE_RSR_W1!![0m
    [33m			Removed WISE_RSR_W2!![0m
    [33m			Removed GaiaDR2v2_BP!![0m
    [33m			Removed GaiaDR2v2_RP!![0m
    [33m			Removed GaiaDR2v2_G!![0m
    [33m			Removed TESS!![0m



```python
import numpy as np

s.add_mag(17.5916,0.0078,'PS1_g')
s.add_mag(17.2319,0.0153,'PS1_r')
s.add_mag(16.0572,0.0069,'PS1_i')
s.add_mag(15.5512,0.033,'PS1_z')
s.add_mag(15.1920,0.0166,'PS1_y')

s.add_mag(18.033, np.sqrt(0.071**2+0.05**2),'GALEX_FUV')
s.add_mag(17.956, np.sqrt(0.047**2+0.05**2),'GALEX_NUV')

s.add_mag(13.825, np.sqrt(0.025**2+0.05**2),'2MASS_J')
s.add_mag(13.255, np.sqrt(0.029**2+0.05**2),'2MASS_H')
s.add_mag(12.947, np.sqrt(0.028**2+0.05**2),'2MASS_Ks')
```

    [33m			Added PS1_g 17.5916 +/- 0.0078!![0m
    [33m			Added PS1_r 17.2319 +/- 0.0153!![0m
    [33m			Added PS1_i 16.0572 +/- 0.0069!![0m
    [33m			Added PS1_z 15.5512 +/- 0.033!![0m
    [33m			Added PS1_y 15.192 +/- 0.0166!![0m
    [33m			Added GALEX_FUV 18.033 +/- 0.08683893136145793!![0m
    [33m			Added GALEX_NUV 17.956 +/- 0.06862215385719105!![0m
    [33m			Added 2MASS_J 13.825 +/- 0.05590169943749475!![0m
    [33m			Added 2MASS_H 13.255 +/- 0.057801384066473706!![0m
    [33m			Added 2MASS_Ks 12.947 +/- 0.05730619512757761!![0m



```python
s.print_mags()
```

    		       Filter       	Magnitude	Uncertainty
    		--------------------	---------	-----------
    		     GALEX_FUV      	 18.0330 	  0.0868   
    		     GALEX_NUV      	 17.9560 	  0.0686   
    		       PS1_g        	 17.5916 	  0.0078   
    		       PS1_r        	 17.2319 	  0.0153   
    		       PS1_i        	 16.0572 	  0.0069   
    		       PS1_z        	 15.5512 	  0.0330   
    		       PS1_y        	 15.1920 	  0.0166   
    		      2MASS_J       	 13.8250 	  0.0559   
    		      2MASS_H       	 13.2550 	  0.0578   
    		      2MASS_Ks      	 12.9470 	  0.0573   
    



```python
from astroAriadne_binary import fitter
```


```python
out_folder = './651211_example'
engine = 'dynesty'
nlive = 800
dlogz = 0.2
bound = 'multi'
sample = 'rwalk'
threads = 120
dynamic = False

setup = [engine, nlive, dlogz, bound, sample, threads, dynamic]


models = ['btsettl','koesterbb']

f = fitter.Fitter()
f.star = s
f.setup = setup
f.av_law = 'fitzpatrick'
f.out_folder = out_folder
f.models = models
f.n_samples = 300000
```


```python
f.prior_setup = {'teff1': ('normal', 3300, 100),
                 'logg1': ('fixed', 4.65),
                 'z1': ('fixed', 0.29),
                 'teff2': (('default'),
                 'logg2': ('default'),
                 'z2': ('default'),
                 'dist': ('normal',133.89, 3),
                 'rad1': ('default'),
                 'rad2': ('default'),
                 'Av': ('default')}
```


```python
f.initialize()
f.fit_binary()
```

    [31mCreation of the directory ./651211_example failed. It might already exist[0m
    [34m
    		*** EXECUTING MAIN FITTING ROUTINE ***[0m
    [34m			Selected engine : [0m[34mDynesty[0m
    [34m			Live points : [0m[34m800[0m
    [34m			log Evidence tolerance : [0m[34m0.2[0m
    [34m			Free parameters : [0m[34m17[0m
    [34m			Bounding : [0m[34mmulti[0m
    [34m			Sampling : [0m[34mrwalk[0m
    [34m			N threads : [0m[34m120[0m
    
    			FITTING MODELS : btsettl_koesterbb


    19712it [05:23, 60.91it/s, +800 | bound: 77 | nc: 1 | ncall: 482851 | eff(%):  4.255 | loglstar:   -inf < 272.227 <    inf | logz: 249.150 +/-  0.159 | dlogz:  0.000 >  0.200]      


    
    [32m			Fitting finished.[0m
    [32m			Best fit parameters are:[0m
    [32m			teff1 : 3232.3254 teff1 : 3232.3254 + 83.4073 - 94.0228 [3024.5654, 3477.9978]
    			logg1 : 4.6500 logg1 : 4.6500 fixed
    			[Fe/H]_1 : 0.2900 [Fe/H]_1 : 0.2900 fixed
    			teff2 : 15946.4368 teff2 : 15946.4368 + 1341.4884 - 1215.7239 [13179.6170, 19446.8831]
    			logg2 : 6.8712 logg2 : 6.8712 + 2.4680 - 0.3110 [6.5000, 9.4897]
    			z2 : 0.0000 [Fe/H]_2 : 0.0000 fixed
    			dist : 133.5310 dist : 133.5310 + 4.9640 - 4.1250 [123.9526, 144.8572]
    			rad1 : 0.2714 rad1 : 0.2714 + 0.0190 - 0.0236 [0.2078, 0.3213]
    			rad2 : 0.0070 rad2 : 0.0070 + 0.0008 - 0.0009 [0.0026, 0.0102]
    			Av : 0.0488 Av : 0.0488 + 0.0545 - 0.0463 [0.0004, 0.1058]
    			Angular Diameter for star1: 0.0187 + 0.0013 - 0.0014 [0.0146, 0.0226]
    			Angular Diameter for star2: 0.0005 + 0.0001 - 0.0001 [0.0002, 0.0007]
    			Grav mass for star1 : 0.1199 + 0.0174 - 0.0201 [0.0705, 0.1686]
    			Grav mass for star2 : 0.0643 + 0.6036 - 0.0604 [0.0039, 9.0282]
    			Star1 Luminosity : 0.0069 + 0.0008 - 0.0005 [0.0053, 0.0091]
    			Star2 Luminosity : 0.0028 + 0.0007 - 0.0006 [0.0004, 0.0050]
    			Excess FUV noise : 0.1107 + 0.7526 - 0.1107 [0.0000, 3.3094]
    			Excess NUV noise : 0.1287 + 0.6272 - 0.1286 [0.0000, 2.4042]
    			Excess PS1_g noise : 0.0304 + 0.0801 - 0.0303 [0.0001, 0.2923]
    			Excess PS1_r noise : 0.0778 + 0.1315 - 0.0778 [0.0000, 0.5540]
    			Excess PS1_i noise : 0.0130 + 0.0827 - 0.0130 [0.0000, 0.2283]
    			Excess PS1_z noise : 0.0427 + 0.2680 - 0.0427 [0.0000, 1.1611]
    			Excess PS1_y noise : 0.0203 + 0.1328 - 0.0203 [0.0000, 0.5516]
    			Excess J noise : 0.0564 + 0.4197 - 0.0564 [0.0000, 1.8731]
    			Excess H noise : 0.0506 + 0.3919 - 0.0506 [0.0000, 1.8899]
    			Excess Ks noise : 0.0604 + 0.3701 - 0.0604 [0.0000, 2.2583]
    [0m[32m			Mamajek Spectral Type for star1 : [0m[32mM3.5V[0m
    [32m			Mamajek Spectral Type for star2 : [0m[32mB5V[0m
    [32m			log Bayesian evidence : [0m[32m249.150 +/-[0m [32m0.203[0m
    [32m			Elapsed time : [0m[32m5 minutes and 44.60 seconds[0m



```python
from astroAriadne_binary import plotter

SEDPlotter = plotter.SEDPlotter
in_file = f"{out_folder}/{models[0]}_{models[1]}_out.pkl"
plots_out_folder = f"{out_folder}/plots"
```


```python
artist = SEDPlotter(in_file, plots_out_folder, pdf=True)
artist.plot_SED_oc(title= 'LAMOST J1013+2724')
```

    
    Initializing plotter.
    
    [31mCreation of the directory ./651211_example/plots failed. It might already exist[0m
    Grid btsettl loaded.
    Grid koesterbb loaded.
    
    Plotter initialized.
    
    Plotting SED
    Grid btsettl loaded.
    Grid koesterbb loaded.



    
![png](output_10_1.png)
    



```python
artist.plot_corner(ignor = ['logg1','z1', 'logg2','z2'])
```

    Plotting corner.



    
![png](output_11_1.png)
    



```python

```
